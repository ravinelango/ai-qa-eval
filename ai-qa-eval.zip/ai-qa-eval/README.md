# eval_playwright_run.py

Tiny **LLM-as-judge** for a Playwright (or pytest) text log.

Interview evidence, not a product. Rules:

- The log is the source of truth
- Expected checks are explicit
- A passing title that contains the word "error" is still a pass
- A flaky retry that later passed is a pass unless `--strict`
- Output is PASS/FAIL + score + reason + failed checks

Default mode is **offline** (no API key). `--live` calls an OpenAI-compatible chat API.

## Run

```bash
python eval_playwright_run.py fixtures/sample_run.txt
python eval_playwright_run.py fixtures/sample_run_fail.txt
python eval_playwright_run.py fixtures/sample_run_fail.txt --json
python eval_playwright_run.py fixtures/sample_run.txt --strict
pytest -q
```

Exit codes: `0` PASS, `1` FAIL, `2` judge could not run.

## Live model (optional)

```bash
export OPENAI_API_KEY=...
python eval_playwright_run.py fixtures/sample_run_fail.txt --live
```

xAI-compatible:

```bash
export GROK_API_KEY=...
export OPENAI_BASE_URL=https://api.x.ai/v1
export EVAL_MODEL=grok-4
python eval_playwright_run.py fixtures/sample_run.txt --live
```

## Log format

```
EXPECTED:
- step one
- step two

<raw Playwright output>
```

## What this is not

Not a trained model. Not agent orchestration. It is a quality gate: expected behavior vs evidence in the run log.
