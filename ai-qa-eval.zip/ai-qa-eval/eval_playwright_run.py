#!/usr/bin/env python3
"""
LLM-as-judge for a Playwright (or pytest) test run.

Default mode is offline/heuristic so the repo runs without an API key.
Set OPENAI_API_KEY (or GROK_API_KEY + OPENAI_BASE_URL) to call a real model.

Usage:
  python eval_playwright_run.py fixtures/sample_run.txt
  python eval_playwright_run.py fixtures/sample_run.txt --json
  python eval_playwright_run.py fixtures/sample_run.txt --live
  python eval_playwright_run.py fixtures/sample_run.txt --strict

Exit codes: 0 = PASS, 1 = FAIL, 2 = the judge itself could not run.
"""

from __future__ import annotations

import argparse
import json
import os
import re
import sys
import urllib.error
import urllib.request
from dataclasses import asdict, dataclass
from typing import Any


DEFAULT_EXPECTED = (
    "All tests pass. No assertion failures, timeouts, or uncaught exceptions."
)
MAX_LOG_CHARS = 8000

JUDGE_PROMPT = """You are a QA judge. Score this automated test run.

Expected behavior:
{expected}

Test run log:
{log}

Reply with ONLY valid JSON:
{
  "verdict": "PASS" or "FAIL",
  "score": 0-100,
  "reason": "one or two sentences",
  "failed_checks": ["short check name", ...]
}

Rules:
- FAIL if an assertion failed, a timeout hit, or the log never reached a passed status.
- FAIL if a required step in Expected behavior is missing from the log.
- PASS only if every expected check is evidenced in the log.
- Do not invent steps that are not in the log.
{strict_rule}"""

STRICT_RULE = "- FAIL if any test is flaky (passed only on a retry) or was skipped.\n"
LENIENT_RULE = "- A test that failed and then passed on a retry (flaky) is not a failure.\n"


class JudgeError(Exception):
    """User-facing judge failure (missing key, bad model reply, bad file)."""


@dataclass
class Judgment:
    verdict: str
    score: int | None
    reason: str
    failed_checks: list[str]
    mode: str


def clip_log(log: str) -> str:
    if len(log) <= MAX_LOG_CHARS:
        return log
    omitted = len(log) - MAX_LOG_CHARS
    return f"[{omitted} characters omitted]\n" + log[-MAX_LOG_CHARS:]


def read_text(path: str) -> str:
    with open(path, "rb") as f:
        data = f.read()
    # UTF-16 (e.g. Windows PowerShell ">"): byte-order mark plus NUL-padded text
    if data.startswith((b"\xff\xfe", b"\xfe\xff")) and b"\x00" in data[:200]:
        return data.decode("utf-16", errors="replace")
    for enc in ("utf-8-sig", "utf-8"):
        try:
            return data.decode(enc)
        except UnicodeDecodeError:
            continue
    # Mostly-UTF-8 with stray bytes: keep the markers, replace only the bad bytes.
    return data.decode("utf-8", errors="replace")


_BULLET = re.compile(r"^\s*(?:[-*\u2022]|\d+[.)])\s+")


def extract_expected(raw: str) -> tuple[str, str]:
    """Optional block at the top of the log: EXPECTED: ... until a blank line.

    Accepts text on the header line, plain lines, and -, *, or numbered
    bullets (indented or not). A bulleted block also ends at the first
    non-bullet line, so a missing blank line does not swallow the log.
    """
    text = raw.replace("\r\n", "\n").replace("\r", "\n").lstrip("\ufeff")
    match = re.match(r"(?i)\s*expected:[ \t]*", text)
    if not match:
        return DEFAULT_EXPECTED, text
    lines = text[match.end():].split("\n")
    expected_lines: list[str] = []
    if lines[0].strip():
        expected_lines.append(lines[0].strip())
    saw_bullet = False
    idx = 1
    while idx < len(lines):
        line = lines[idx]
        if not line.strip():
            idx += 1
            break
        if _BULLET.match(line):
            saw_bullet = True
        elif saw_bullet:
            break
        expected_lines.append(line.strip())
        idx += 1
    expected = "\n".join(expected_lines)
    return expected or DEFAULT_EXPECTED, "\n".join(lines[idx:])


_PCT = r"(?:\[\s*\d+%\s*\])?\s*$"
_PASS_MARK = re.compile(r"^\s*[\u2713\u2714]")
_FAIL_MARK = re.compile(r"^\s*(?:[\u2718\u2717\u2715\u00d7]|ERROR\b)")


def _is_pass_line(line: str) -> bool:
    if _PASS_MARK.match(line):
        return True
    if re.search(r"\bPASSED\b", line) and "FAILED" not in line:
        return True
    return False


def _is_fail_line(line: str) -> bool:
    if _FAIL_MARK.match(line):
        return True
    if re.search(r"\bFAILED\b", line):
        return True
    return False


_ITEM = (
    r"\d+\s+(?:passed|failed|flaky|skipped|interrupted|did not run|errors?|"
    r"timed out|warnings?|deselected|xfailed|xpassed|rerun)"
)
# A summary line holds only counts: "3 passed (4.5s)", "== 1 failed, 2 passed in 0.1s =="
# Counts are never read from test titles or other log text.
_SUMMARY_LINE = re.compile(
    rf"^[\s=\ufffd]*{_ITEM}(?:\s*,\s*{_ITEM})*(?:\s+in\s+[\d.]+\s*s)?(?:\s*\([^)]*\))?[\s=]*$", re.I
)
_COUNT = re.compile(
    r"(\d+)\s+(passed|failed|flaky|skipped|interrupted|did not run|errors?|timed out)", re.I
)
_BLOCK_HEADER = re.compile(r"^(\s*)\d+\)\s+(\S.*)$")  # "  1) [chromium] › a.spec.ts › title"
_TIMEOUT_SIG = re.compile(
    r"\btimed out\b|\btimeout (?:of )?\d+\s*ms exceeded|\bTimeoutError\b", re.I
)
_ASSERT_SIG = re.compile(r"^\s*(?:E\s+)?[\w.]*AssertionErrors?\b", re.I)
_ERROR_SIG = re.compile(
    r"^\s*(?:E\s+)?[\w.]*(?:Error|Exception)s?\s*:|\buncaught (?:exception|error|\w*Error)\b", re.I
)
_ANSI = re.compile(r"\x1b\[[0-9;?]*[ -/]*[@-~]")
_STOP = {"a", "an", "the", "is", "to", "and", "of", "for", "in", "on"}


def _title(line: str) -> str:
    """Test title without marker, index, retry tag, duration or status word."""
    s = line.strip()
    pytest_fail = bool(re.match(r"(?:FAILED|ERROR)\b", s))
    s = re.sub(r"^(?:[\u2713\u2714\u2718\u2717\u2715\u00d7]|PASSED\b|FAILED\b|ERROR\b)\s*", "", s)
    s = re.sub(r"^\d+\s+", "", s)
    s = re.sub(r"\(retry #\d+\)", "", s)
    s = re.sub(r"\(\s*\d+(?:\.\d+)?\s*(?:ms|s|m)\s*\)", "", s)
    s = re.sub(rf"\s+(?:PASSED|FAILED|ERROR)\s*{_PCT}", "", s)
    if pytest_fail:
        s = re.sub(r"\s+-\s+.*$", "", s)
    s = re.sub(r"[\s\u2500\u2501]+$", "", s)
    return " ".join(s.split()).lower()


def _words(text: str) -> set[str]:
    return set(re.findall(r"[a-z0-9]+", text.lower()))


def _parse_checks(expected: str) -> list[str]:
    """Steps that need evidence. Generic "all tests pass" and negative
    statements ("No timeouts") are covered by failure detection instead."""
    if not expected or expected.strip() == DEFAULT_EXPECTED:
        return []
    checks: list[str] = []
    for line in expected.splitlines():
        item = _BULLET.sub("", line.strip()).strip()
        if not item:
            continue
        lead = re.match(r"(?i)all tests pass(?:ed)?\b[\s.,;:]*(?:and\s+)?", item)
        if lead:
            rest = item[lead.end():]
            parts = [p.strip() for p in re.split(r"(?<=[.;])\s+", rest) if p.strip()]
            checks.extend(p for p in parts if not re.match(r"(?i)(?:no|without)\b", p))
        else:
            checks.append(item)
    return checks


def _check_words(check: str) -> list[str]:
    return [w for w in re.findall(r"[a-z0-9]+", check.lower()) if w not in _STOP]


def _evidenced(check: str, lines: list[str]) -> bool:
    """Every word of the check (minus filler words) as whole words on one line."""
    words = _check_words(check)
    return bool(words) and any(all(w in _words(line) for w in words) for line in lines)


def heuristic_judge(expected: str, log: str, strict: bool = False) -> Judgment:
    failed: list[str] = []
    normalized = log.replace("\r\n", "\n").replace("\r", "\n")
    normalized = _ANSI.sub("", normalized)  # colour codes from CI logs

    pass_lines: list[tuple[int, str]] = []
    fail_lines: list[tuple[int, str]] = []
    neutral: list[tuple[str, str | None]] = []  # (line, title of enclosing error block)
    counts: dict[str, int] = {}
    has_summary = False
    block_title: str | None = None
    block_indent = -1

    for i, line in enumerate(normalized.split("\n")):
        if _is_pass_line(line):
            pass_lines.append((i, line))
            block_title = None
        elif _is_fail_line(line):
            fail_lines.append((i, line))
            block_title = None
        elif _SUMMARY_LINE.match(line):
            has_summary = True
            block_title = None
            for n, kind in _COUNT.findall(line):
                kind = kind.lower()
                kind = "errors" if kind.startswith("error") else kind
                counts[kind] = counts.get(kind, 0) + int(n)
        else:
            header = _BLOCK_HEADER.match(line)
            if header:
                block_title = _title(header.group(2))
                block_indent = len(header.group(1))
            elif block_title is not None and line.strip():
                if len(line) - len(line.lstrip()) <= block_indent:
                    block_title = None
            neutral.append((line, None if header else block_title))

    # A failed attempt followed by a pass of the same title is a retry, not a failure.
    last_pass: dict[str, int] = {}
    for i, line in pass_lines:
        last_pass[_title(line)] = i
    unrecovered: list[str] = []
    recovered: set[str] = set()
    for i, line in fail_lines:
        title = _title(line)
        if title and last_pass.get(title, -1) > i:
            recovered.add(title)
        else:
            unrecovered.append(line)

    n_passed = counts.get("passed", 0)
    n_flaky = counts.get("flaky", 0)
    hard_failed = counts.get("failed", 0) + counts.get("timed out", 0)
    flaky = n_flaky > 0 or bool(recovered)

    if counts.get("interrupted", 0) or counts.get("did not run", 0):
        failed.append("run interrupted")
    if counts.get("errors", 0):
        failed.append("error in log")
    if hard_failed or unrecovered:
        failed.append("assertion or test failure in log")
    if counts.get("timed out", 0):
        failed.append("timeout")

    # Error text is excused only inside the numbered error block of a test that
    # later passed on retry. Errors anywhere else always count.
    summary_says_only_flaky = (
        has_summary and n_flaky > 0 and not hard_failed and not unrecovered
    )
    for line, owner in neutral:
        if owner is not None and (owner in recovered or summary_says_only_flaky):
            continue
        if "\u203a" in line and not _ERROR_SIG.match(line):
            continue  # a test title listed under the summary, not an error
        if _TIMEOUT_SIG.search(line):
            failed.append("timeout")
        elif _ASSERT_SIG.match(line):
            failed.append("assertion or test failure in log")
        elif _ERROR_SIG.search(line):
            failed.append("error in log")

    if strict and flaky:
        failed.append("flaky tests present")
    if strict and counts.get("skipped", 0):
        failed.append("skipped tests present")

    if has_summary:
        reached_pass = n_passed + n_flaky > 0
    else:
        reached_pass = bool(pass_lines)
    if not reached_pass:
        failed.append("log never reached a passed status")

    ok_lines = [line for _, line in pass_lines] + [line for line, _ in neutral]
    for check in _parse_checks(expected):
        if not _check_words(check):
            continue
        if _evidenced(check, unrecovered):
            failed.append(f"expected step failed: {check}")
        elif not _evidenced(check, ok_lines):
            failed.append(f"missing evidence: {check}")

    failed = list(dict.fromkeys(failed))

    if failed:
        reason = "Heuristic judge found failures or missing expected evidence in the log."
        return Judgment(
            verdict="FAIL",
            score=max(20, 80 - 15 * len(failed)),
            reason=reason,
            failed_checks=failed,
            mode="heuristic",
        )

    reason = "Heuristic judge found no failure keywords and expected checks are present."
    if flaky:
        reason = "Heuristic judge accepted a retry that later passed."
    return Judgment(
        verdict="PASS",
        score=95,
        reason=reason,
        failed_checks=[],
        mode="heuristic",
    )


def _extract_verdict_json(content: str) -> dict[str, Any]:
    decoder = json.JSONDecoder()
    found: dict[str, Any] | None = None
    i = 0
    while i < len(content):
        if content[i] == "{":
            try:
                obj, end = decoder.raw_decode(content, i)
            except json.JSONDecodeError:
                i += 1
                continue
            if isinstance(obj, dict) and "verdict" in obj:
                found = obj
            i = end
        else:
            i += 1
    if found is None:
        raise JudgeError("model reply did not contain judgment JSON")
    return found


def _coerce_score(raw: Any) -> int | None:
    if raw is None:
        return None
    if isinstance(raw, bool):
        raise JudgeError("invalid score")
    if isinstance(raw, float):
        value = int(round(raw))
    elif isinstance(raw, int):
        value = raw
    else:
        match = re.search(r"-?\d+(?:\.\d+)?", str(raw))
        if not match:
            return None
        value = int(round(float(match.group())))
    if value < 0 or value > 100:
        raise JudgeError(f"score out of range: {raw}")
    return value


def _normalize_verdict(raw: Any) -> str:
    text = str(raw or "").strip().upper()
    if text in {"PASS", "PASSED"}:
        return "PASS"
    if text in {"FAIL", "FAILED"}:
        return "FAIL"
    raise JudgeError(f"unknown verdict: {raw}")


def _normalize_checks(raw: Any) -> list[str]:
    if raw is None:
        return []
    if isinstance(raw, str):
        return [raw] if raw else []
    if isinstance(raw, list):
        return [str(item) for item in raw if item is not None and str(item).strip()]
    return [str(raw)]


def _api_error_message(payload: Any) -> str | None:
    """Error text from an OpenAI-style body, whatever shape "error" has."""
    if not isinstance(payload, dict) or not payload.get("error"):
        return None
    err = payload["error"]
    if isinstance(err, dict):
        return str(err.get("message") or err)
    return str(err)



def _build_prompt(expected: str, log: str, strict: bool) -> str:
    """Fill the template without interpreting braces inside expected or log."""
    marker_e = "<<<EXPECTED>>>"
    marker_l = "<<<LOG>>>"
    prompt = JUDGE_PROMPT.replace("{strict_rule}", STRICT_RULE if strict else LENIENT_RULE)
    prompt = prompt.replace("{expected}", marker_e).replace("{log}", marker_l)
    return prompt.replace(marker_e, expected).replace(marker_l, clip_log(log))


def live_judge(expected: str, log: str, strict: bool = False) -> Judgment:
    api_key = os.environ.get("OPENAI_API_KEY") or os.environ.get("GROK_API_KEY")
    if not api_key:
        raise JudgeError("LIVE mode needs OPENAI_API_KEY or GROK_API_KEY")

    base = os.environ.get("OPENAI_BASE_URL", "https://api.openai.com/v1").rstrip("/")
    model = os.environ.get("EVAL_MODEL", "gpt-4o-mini")
    prompt = _build_prompt(expected, log, strict)
    body = json.dumps(
        {
            "model": model,
            "temperature": 0,
            "messages": [{"role": "user", "content": prompt}],
        }
    ).encode()
    req = urllib.request.Request(
        f"{base}/chat/completions",
        data=body,
        headers={
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
        },
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=45) as resp:
            raw = resp.read().decode("utf-8", errors="replace")
    except urllib.error.HTTPError as exc:
        err_body = exc.read().decode(errors="replace") if exc.fp else ""
        message = err_body.strip()[:300]
        try:
            message = _api_error_message(json.loads(err_body)) or message
        except json.JSONDecodeError:
            pass
        raise JudgeError(f"Model call failed: HTTP {exc.code} {message}".strip()) from exc
    except OSError as exc:  # URLError, timeouts, connection errors
        raise JudgeError(f"Model call failed: {exc}") from exc

    try:
        payload = json.loads(raw)
    except json.JSONDecodeError as exc:
        raise JudgeError("non-JSON model response") from exc
    if not isinstance(payload, dict):
        raise JudgeError(f"unexpected model response: {raw[:200]}")
    api_error = _api_error_message(payload)
    if api_error:
        raise JudgeError(api_error)
    choices = payload.get("choices")
    if not isinstance(choices, list) or not choices:
        raise JudgeError("empty choices")
    message = choices[0].get("message") if isinstance(choices[0], dict) else None
    content = message.get("content") if isinstance(message, dict) else None
    if not isinstance(content, str) or not content.strip():
        refusal = message.get("refusal") if isinstance(message, dict) else None
        raise JudgeError(f"model returned no text content{f' (refusal: {refusal})' if refusal else ''}")
    data = _extract_verdict_json(content)
    verdict = _normalize_verdict(data.get("verdict"))
    score = _coerce_score(data.get("score"))
    checks = _normalize_checks(data.get("failed_checks"))
    if checks and verdict == "PASS":
        verdict = "FAIL"
    return Judgment(
        verdict=verdict,
        score=score,
        reason=str(data.get("reason") or ""),
        failed_checks=checks,
        mode="live",
    )


def print_human(j: Judgment) -> None:
    score = "n/a" if j.score is None else j.score
    print(f"VERDICT: {j.verdict}   SCORE: {score}   MODE: {j.mode}")
    print(f"REASON:  {j.reason}")
    if j.failed_checks:
        print("FAILED CHECKS:")
        for item in j.failed_checks:
            print(f"  - {item}")


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="LLM-as-judge for a Playwright test log")
    parser.add_argument("log_file", help="Path to a Playwright / pytest text log")
    parser.add_argument("--live", action="store_true", help="Call a real model")
    parser.add_argument("--json", action="store_true", help="Print JSON only")
    parser.add_argument("--strict", action="store_true", help="Fail on flaky or skipped tests")
    try:
        args = parser.parse_args(argv)
        raw = read_text(args.log_file)
        expected, log = extract_expected(raw)
        if args.live:
            judgment = live_judge(expected, log, strict=args.strict)
        else:
            judgment = heuristic_judge(expected, log, strict=args.strict)
    except JudgeError as exc:
        print(f"JUDGE ERROR: {exc}", file=sys.stderr)
        return 2
    except FileNotFoundError as exc:
        print(f"JUDGE ERROR: {exc}", file=sys.stderr)
        return 2
    except OSError as exc:
        print(f"JUDGE ERROR: {exc}", file=sys.stderr)
        return 2

    if args.json:
        print(json.dumps(asdict(judgment), indent=2))
    else:
        print_human(judgment)
    return 0 if judgment.verdict == "PASS" else 1


if __name__ == "__main__":
    sys.exit(main())
