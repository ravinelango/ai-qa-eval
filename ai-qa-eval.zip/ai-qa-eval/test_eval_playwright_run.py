"""Tests for eval_playwright_run.py.  Run:  pytest -q

Live mode is tested against a local mock of the chat-completions endpoint,
so no API key or network access is needed.
"""

from __future__ import annotations

import json
import threading
from http.server import BaseHTTPRequestHandler, HTTPServer

import pytest

import eval_playwright_run as ev

PW_PASS = (
    "Running 3 tests using 1 worker\n\n"
    "  \u2713  1 [chromium] \u203a login.spec.ts:5:1 \u203a user can log in (1.2s)\n"
    "  \u2713  2 [chromium] \u203a cart.spec.ts:9:1 \u203a add item to cart (900ms)\n"
    "  \u2713  3 [chromium] \u203a checkout.spec.ts:4:1 \u203a checkout completes (2.0s)\n\n"
    "  3 passed (4.5s)\n"
)
PW_FAIL = (
    "Running 2 tests using 1 worker\n\n"
    "  \u2713  1 login.spec.ts:5:1 \u203a user can log in (1.2s)\n"
    "  \u2718  2 cart.spec.ts:9:1 \u203a add item to cart (30.0s)\n\n"
    "  1) cart.spec.ts:9:1 \u203a add item to cart\n"
    "    Test timeout of 30000ms exceeded.\n"
    "    Error: expect(locator).toBeVisible()\n\n"
    "  1 failed\n"
    "  1 passed (31s)\n"
)
PW_FLAKY = (
    "Running 1 test using 1 worker\n\n"
    "  \u2718  1 [chromium] \u203a a.spec.ts:3:1 \u203a loads dashboard (1.0s)\n"
    "  \u2713  2 [chromium] \u203a a.spec.ts:3:1 \u203a loads dashboard (retry #1) (800ms)\n\n"
    "  1) [chromium] \u203a a.spec.ts:3:1 \u203a loads dashboard\n"
    "    Error: expect(locator).toBeVisible()\n\n"
    "  1 flaky\n"
)
PYTEST_PASS = (
    "tests/test_login.py::test_login PASSED                     [ 50%]\n"
    "tests/test_cart.py::test_add_item PASSED                   [100%]\n"
    "============== 2 passed in 0.12s ==============\n"
)
PYTEST_FAIL = (
    "tests/test_login.py::test_login PASSED                     [ 50%]\n"
    "tests/test_cart.py::test_add_item FAILED                   [100%]\n"
    "E       AssertionError: assert 1 == 2\n"
    "FAILED tests/test_cart.py::test_add_item - AssertionError: assert 1 == 2\n"
    "========= 1 failed, 1 passed in 0.12s =========\n"
)


def judge(raw: str, strict: bool = False) -> ev.Judgment:
    expected, log = ev.extract_expected(raw.strip())
    return ev.heuristic_judge(expected, log, strict=strict)


# ----------------------------------------------------------- heuristic ----

HEURISTIC_CASES = {
    # baseline
    "clean_pass": (PW_PASS, "PASS"),
    "clean_fail": (PW_FAIL, "FAIL"),
    "pytest_pass": (PYTEST_PASS, "PASS"),
    "pytest_fail": (PYTEST_FAIL, "FAIL"),
    "expected_met": ("EXPECTED:\n- user can log in\n- add item to cart\n- checkout completes\n\n" + PW_PASS, "PASS"),
    "expected_missing": ("EXPECTED:\n- user can log in\n- password reset email sent\n\n" + PW_PASS, "FAIL"),
    # must not pass
    "empty_log": ("", "FAIL"),
    "never_reached_passed": ("Running 3 tests using 1 worker\n", "FAIL"),
    "only_flaky_and_skipped_words": ("Running 3 tests\n  2 skipped\n", "FAIL"),
    "interrupted": ("Running 3 tests\n  1 passed\n  1 interrupted\n  2 did not run\n", "FAIL"),
    "errors_plural": ("Running 1 test\n  1 passed, 2 errors in 0.3s\n", "FAIL"),
    "exception_class_plural": ("Running 1 test\n  AssertionErrors: x\n  1 passed\n", "FAIL"),
    "no_tests_found": ("Error: No tests found\n", "FAIL"),
    "zero_passed": ("  \u2713 login\n  0 passed\n", "FAIL"),
    "substring_is_not_evidence": (
        "EXPECTED:\n- log out works\n\nRunning 1 test\n  \u2713 login page artworks render\n  1 passed\n",
        "FAIL",
    ),
    "expected_step_failed": (
        "EXPECTED:\n- checkout completes\n\n  \u2713 login\n  \u2718 checkout completes\n  1 passed\n",
        "FAIL",
    ),
    "uncaught_exception": ("  \u2713 a (1s)\n  1 passed\nUncaught exception in global teardown\n", "FAIL"),
    "bom_does_not_hide_expected": ("\ufeffEXPECTED:\n- password reset\n\n" + PW_PASS, "FAIL"),
    # must not fail
    "error_word_in_passing_title": (
        "Running 1 test\n  \u2713  1 login.spec.ts \u203a shows error message on bad password (1s)\n\n  1 passed (1s)\n",
        "PASS",
    ),
    "timeout_word_in_passing_title": ("  \u2713 session timed out banner is shown (1s)\n  1 passed\n", "PASS"),
    "zero_failed_summary": ("===== 5 passed, 0 failed in 1.2s =====\n", "PASS"),
    "timeout_config_line": ("Using config: timeout 30000\nRunning 1 test\n  \u2713 a (1s)\n  1 passed\n", "PASS"),
    "single_word_check": ("EXPECTED:\n- checkout\n\n  \u2713 checkout (1s)\n  1 passed\n", "PASS"),
    "retry_then_pass": (PW_FLAKY, "PASS"),
    "skipped_with_passes": ("  \u2713 a (1s)\n  1 skipped\n  1 passed\n", "PASS"),
    "lowercase_header": ("expected:\n- user can log in\n\n" + PW_PASS, "PASS"),
    "header_without_blank_line": ("EXPECTED:\n- user can log in\n" + PW_PASS.replace("\n\n", "\n"), "PASS"),
    "crlf": ("EXPECTED:\r\n- user can log in\r\n\r\n" + PW_PASS.replace("\n", "\r\n"), "PASS"),
    "inline_expected": ("EXPECTED: checkout completes\n\n" + PW_PASS, "PASS"),
}


@pytest.mark.parametrize("name", HEURISTIC_CASES)
def test_heuristic_verdict(name):
    raw, want = HEURISTIC_CASES[name]
    j = judge(raw)
    assert j.verdict == want, j.failed_checks
    assert j.mode == "heuristic"
    assert (j.failed_checks == []) == (want == "PASS")


def test_clean_fail_names_each_problem():
    checks = judge(PW_FAIL).failed_checks
    assert "assertion or test failure in log" in checks
    assert "timeout" in checks
    assert "error in log" in checks


def test_failed_expected_step_is_reported_as_failed_not_missing():
    j = judge("EXPECTED:\n- checkout completes\n\n  \u2718 checkout completes\n  1 passed\n")
    assert "expected step failed: checkout completes" in j.failed_checks


def test_missing_pass_status_is_named():
    assert "log never reached a passed status" in judge("Running 3 tests\n").failed_checks


def test_flaky_pass_is_noted_in_reason():
    assert "retry" in judge(PW_FLAKY).reason


@pytest.mark.parametrize("raw", [PW_FLAKY, "  \u2713 a (1s)\n  1 skipped\n  1 passed\n"])
def test_strict_fails_flaky_and_skipped(raw):
    assert judge(raw).verdict == "PASS"
    assert judge(raw, strict=True).verdict == "FAIL"


def test_retry_does_not_excuse_a_different_failing_test():
    log = "  \u2718 a (1s)\n  \u2713 a (retry #1) (1s)\n  \u2718 b (1s)\n  \u2718 b (retry #1) (1s)\n  1 flaky\n  1 failed\n"
    assert judge(log).verdict == "FAIL"


def test_score_drops_with_more_failures_and_has_a_floor():
    assert judge(PW_FAIL).score == 35
    many = "EXPECTED:\n" + "\n".join(f"- thing{i} widget{i}" for i in range(10)) + "\n\n  1 passed\n"
    assert judge(many).score == 20


# ------------------------------------------------------ extract_expected ----

def test_extract_default_when_no_header():
    expected, log = ev.extract_expected("1 passed")
    assert expected == ev.DEFAULT_EXPECTED and log == "1 passed"


def test_extract_returns_block_and_rest():
    expected, log = ev.extract_expected("Expected:\n- a b\n- c d\n\nline1\n\nline2")
    assert expected == "- a b\n- c d"
    assert log == "line1\n\nline2"


def test_extract_without_blank_line_stops_at_first_non_bullet():
    expected, log = ev.extract_expected("EXPECTED:\n- a b\nRunning 1 test\n1 passed")
    assert expected == "- a b"
    assert log.startswith("Running 1 test")


# ------------------------------------------------------------ live mode ----

class _Mock:
    def __init__(self):
        self.content, self.status, self.raw, self.seen = "", 200, None, {}

    def reply(self, content="", status=200, raw=None):
        self.content, self.status, self.raw = content, status, raw


@pytest.fixture()
def mock_api(monkeypatch):
    mock = _Mock()

    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *args):
            pass

        def do_POST(self):
            body = json.loads(self.rfile.read(int(self.headers["Content-Length"])))
            mock.seen = {
                "path": self.path,
                "auth": self.headers["Authorization"],
                "model": body["model"],
                "prompt": body["messages"][0]["content"],
            }
            out = mock.raw
            if out is None:
                out = json.dumps({"choices": [{"message": {"content": mock.content}}]})
            self.send_response(mock.status)
            self.end_headers()
            self.wfile.write(out.encode())

    server = HTTPServer(("127.0.0.1", 0), Handler)
    threading.Thread(target=server.serve_forever, kwargs={"poll_interval": 0.01}, daemon=True).start()
    monkeypatch.setenv("OPENAI_API_KEY", "test-key")
    monkeypatch.delenv("GROK_API_KEY", raising=False)
    monkeypatch.delenv("EVAL_MODEL", raising=False)
    monkeypatch.setenv("OPENAI_BASE_URL", f"http://127.0.0.1:{server.server_port}/v1/")
    yield mock
    server.shutdown()
    server.server_close()


def reply(**overrides) -> str:
    return json.dumps({"verdict": "PASS", "score": 90, "reason": "ok", "failed_checks": [], **overrides})


def test_live_pass_and_request_shape(mock_api):
    mock_api.reply(reply())
    j = ev.live_judge(ev.DEFAULT_EXPECTED, PW_PASS)
    assert (j.verdict, j.score, j.mode) == ("PASS", 90, "live")
    assert mock_api.seen["path"] == "/v1/chat/completions"
    assert mock_api.seen["auth"] == "Bearer test-key"
    assert mock_api.seen["model"] == "gpt-4o-mini"
    assert "3 passed" in mock_api.seen["prompt"]


def test_live_fail(mock_api):
    mock_api.reply(reply(verdict="FAIL", score=10, failed_checks=["x"]))
    j = ev.live_judge(ev.DEFAULT_EXPECTED, PW_FAIL)
    assert (j.verdict, j.failed_checks) == ("FAIL", ["x"])


@pytest.mark.parametrize(
    "content",
    [
        "```json\n" + reply() + "\n```",
        "Here you go {note}: " + reply() + " Hope that helps {smile}",
        'Thinking {"step": 1} done. ' + reply(),
    ],
    ids=["fenced", "prose_with_braces", "other_json_first"],
)
def test_live_finds_json_in_noisy_reply(mock_api, content):
    mock_api.reply(content)
    assert ev.live_judge("x", "y").verdict == "PASS"


@pytest.mark.parametrize("raw,want", [("90/100", 90), (87.6, 88), ("72", 72), (None, None), ("high", None)])
def test_live_score_coercion(mock_api, raw, want):
    mock_api.reply(reply(score=raw))
    j = ev.live_judge("x", "y")
    assert j.verdict == "PASS" and j.score == want


@pytest.mark.parametrize("bad", [450, -5])
def test_live_score_out_of_range_is_judge_error(mock_api, bad):
    mock_api.reply(reply(score=bad))
    with pytest.raises(ev.JudgeError, match="score"):
        ev.live_judge("x", "y")


@pytest.mark.parametrize("raw,want", [("Passed", "PASS"), (" pass ", "PASS"), ("failed", "FAIL")])
def test_live_verdict_normalised(mock_api, raw, want):
    mock_api.reply(reply(verdict=raw))
    assert ev.live_judge("x", "y").verdict == want


def test_live_unknown_verdict_is_judge_error(mock_api):
    mock_api.reply(reply(verdict="MAYBE"))
    with pytest.raises(ev.JudgeError, match="verdict"):
        ev.live_judge("x", "y")


def test_live_pass_with_failed_checks_becomes_fail(mock_api):
    mock_api.reply(reply(failed_checks=["checkout failed"]))
    j = ev.live_judge("x", "y")
    assert j.verdict == "FAIL" and j.failed_checks == ["checkout failed"]


def test_live_failed_checks_string_stays_one_item(mock_api):
    mock_api.reply(reply(verdict="FAIL", failed_checks="timeout"))
    assert ev.live_judge("x", "y").failed_checks == ["timeout"]


@pytest.mark.parametrize(
    "kwargs",
    [
        {"content": "I cannot judge this."},
        {"content": '{"verdict": "PASS", "score": 9'},
        {"status": 500},
        {"raw": '{"error": {"message": "rate limited"}}'},
        {"raw": "<html>gateway</html>"},
        {"raw": '{"choices": []}'},
    ],
    ids=["no_json", "truncated_json", "http_500", "api_error_body", "non_json_body", "empty_choices"],
)
def test_live_bad_responses_raise_judge_error(mock_api, kwargs):
    mock_api.reply(**kwargs)
    with pytest.raises(ev.JudgeError):
        ev.live_judge("x", "y")


def test_live_api_error_message_is_surfaced(mock_api):
    mock_api.reply(raw='{"error": {"message": "rate limited"}}')
    with pytest.raises(ev.JudgeError, match="rate limited"):
        ev.live_judge("x", "y")


def test_live_long_log_keeps_the_tail(mock_api):
    log = "  \u2713 step ok (1s)\n" * 1500 + "  1 failed\n  Error: expect(received).toBe(expected)\n"
    mock_api.reply(reply(verdict="FAIL"))
    ev.live_judge("x", log)
    prompt = mock_api.seen["prompt"]
    assert "1 failed" in prompt and "Error: expect(received)" in prompt
    assert "characters omitted" in prompt


def test_clip_log_bounds():
    assert ev.clip_log("short") == "short"
    clipped = ev.clip_log("a" * 50000)
    assert len(clipped) < ev.MAX_LOG_CHARS + 100


def test_live_log_with_braces_does_not_break_prompt(mock_api):
    mock_api.reply(reply(verdict="FAIL"))
    ev.live_judge("x", "  \u2718 checkout {cart} failed {0} {expected}")
    assert "{cart}" in mock_api.seen["prompt"]


def test_live_without_key_is_judge_error(monkeypatch):
    monkeypatch.delenv("OPENAI_API_KEY", raising=False)
    monkeypatch.delenv("GROK_API_KEY", raising=False)
    with pytest.raises(ev.JudgeError, match="API_KEY"):
        ev.live_judge("x", "y")


def test_live_unreachable_host_is_judge_error(monkeypatch):
    monkeypatch.setenv("OPENAI_API_KEY", "k")
    monkeypatch.setenv("OPENAI_BASE_URL", "http://127.0.0.1:9/v1")
    with pytest.raises(ev.JudgeError, match="Model call failed"):
        ev.live_judge("x", "y")


# ------------------------------------------------------------------ CLI ----

def write(tmp_path, text, name="run.txt", binary=False):
    p = tmp_path / name
    p.write_bytes(text) if binary else p.write_text(text, encoding="utf-8")
    return str(p)


def test_cli_exit_0_on_pass(tmp_path, capsys):
    assert ev.main([write(tmp_path, PW_PASS)]) == 0
    assert capsys.readouterr().out.startswith("VERDICT: PASS   SCORE: 95   MODE: heuristic")


def test_cli_exit_1_on_fail(tmp_path, capsys):
    assert ev.main([write(tmp_path, PW_FAIL)]) == 1
    out = capsys.readouterr().out
    assert "VERDICT: FAIL" in out and "FAILED CHECKS:" in out


def test_cli_json_output(tmp_path, capsys):
    assert ev.main([write(tmp_path, PW_FAIL), "--json"]) == 1
    data = json.loads(capsys.readouterr().out)
    assert set(data) == {"verdict", "score", "reason", "failed_checks", "mode"}
    assert data["verdict"] == "FAIL"


def test_cli_strict_flag(tmp_path):
    path = write(tmp_path, PW_FLAKY)
    assert ev.main([path]) == 0
    assert ev.main([path, "--strict"]) == 1


def test_cli_exit_2_on_missing_file(tmp_path, capsys):
    assert ev.main([str(tmp_path / "nope.txt")]) == 2
    captured = capsys.readouterr()
    assert captured.out == "" and "JUDGE ERROR" in captured.err


def test_cli_exit_2_on_live_without_key(tmp_path, monkeypatch, capsys):
    monkeypatch.delenv("OPENAI_API_KEY", raising=False)
    monkeypatch.delenv("GROK_API_KEY", raising=False)
    assert ev.main([write(tmp_path, PW_PASS), "--live"]) == 2
    assert "JUDGE ERROR" in capsys.readouterr().err


def test_cli_exit_2_on_bad_model_reply(tmp_path, mock_api, capsys):
    mock_api.reply("no json here")
    assert ev.main([write(tmp_path, PW_PASS), "--live"]) == 2
    assert "Traceback" not in capsys.readouterr().err


def test_cli_live_null_score_prints_na(tmp_path, mock_api, capsys):
    mock_api.reply(reply(score=None))
    assert ev.main([write(tmp_path, PW_PASS), "--live"]) == 0
    assert "SCORE: n/a" in capsys.readouterr().out


def test_cli_non_utf8_file_does_not_crash(tmp_path):
    assert ev.main([write(tmp_path, b"\xff\xfe  1 passed\n", binary=True)]) == 0


def test_cli_bom_file_still_reads_expected_block(tmp_path):
    path = write(tmp_path, ("\ufeffEXPECTED:\n- password reset\n\n" + PW_PASS))
    assert ev.main([path]) == 1


# ===================================================================== #
# Second round: cases outside the first suite                            #
# ===================================================================== #

OK = "  \u2713  1 [chromium] \u203a a.spec.ts:3:1 \u203a "
SUM = "\n  1 passed (1s)\n"
FLAKY_PLUS_REAL_FAILURE = (
    "  \u2718 a (1s)\n  \u2713 a (retry #1) (1s)\n  \u2718 b (1s)\n  \u2718 b (retry #1) (1s)\n  1 flaky\n"
)
SCATTERED = (
    "EXPECTED:\n- reset password email\n\n"
    "  \u2713 reset cart (1s)\n  \u2713 password login (1s)\n  \u2713 email field visible (1s)\n  3 passed\n"
)

ROUND_TWO_CASES = {
    # keywords in passing titles or harmless lines must not fail the run
    "title_has_n_failed": (OK + "locks account after 3 failed logins (1s)" + SUM, "PASS"),
    "title_has_n_errors": (OK + "shows 2 errors on invalid form (1s)" + SUM, "PASS"),
    "title_has_n_passed_only": ("Running 2 tests\n  \u2718 shows 3 passed badges (1s)\n", "FAIL"),
    "title_has_interrupted": (OK + "resumes interrupted upload (1s)" + SUM, "PASS"),
    "title_has_did_not_run": (OK + "flags jobs that did not run (1s)" + SUM, "PASS"),
    "title_has_uncaught_exception": (OK + "shows toast on uncaught exception (1s)" + SUM, "PASS"),
    "slow_file_named_failed": (PW_PASS + "  Slow test file: [chromium] \u203a failed-login.spec.ts (16.2s)\n", "PASS"),
    "neutral_line_with_error_word": ("[WebServer] GET /api/error-codes 200\n" + PW_PASS, "PASS"),
    "config_line_timeout_of": ("Using global timeout of 60000ms\n" + PW_PASS, "PASS"),
    "pytest_xfailed": ("tests/t.py::test_a PASSED [100%]\n==== 1 passed, 1 xfailed in 0.1s ====\n", "PASS"),
    "pytest_quiet": ("..                                   [100%]\n2 passed in 0.01s\n", "PASS"),
    "heavy_check_mark": ("  \u2714 a (1s)\n  \u2714 b (1s)\n", "PASS"),
    # flaky handling
    "flaky_with_expected_block": ("EXPECTED:\n- loads dashboard\n\n" + PW_FLAKY, "PASS"),
    "flaky_plus_test_that_fails_twice": (FLAKY_PLUS_REAL_FAILURE, "FAIL"),
    "flaky_plus_unrelated_error": (PW_FLAKY + "Error: global teardown timed out\n", "FAIL"),
    # errors that are not a bare "Error:"
    "typed_error_after_pass_summary": (
        PW_PASS + "TypeError: Cannot read properties of undefined (reading 'id')\n    at globalTeardown (teardown.ts:4:9)\n",
        "FAIL",
    ),
    "timeouterror_after_pass_summary": (PW_PASS + "TimeoutError: page.goto: Timeout 30000ms exceeded.\n", "FAIL"),
    "pytest_collection_error": ("ERROR tests/test_x.py - ImportError: no module\n==== 1 error in 0.1s ====\n", "FAIL"),
    "other_fail_markers": ("  \u2717 a (1s)\n  \u2713 b (1s)\n", "FAIL"),
    # EXPECTED block shapes: a check must never be dropped silently
    "indented_bullets": ("EXPECTED:\n  - password reset email sent\n\n" + PW_PASS, "FAIL"),
    "star_bullets": ("EXPECTED:\n* password reset email sent\n\n" + PW_PASS, "FAIL"),
    "numbered_bullets": ("EXPECTED:\n1. password reset email sent\n\n" + PW_PASS, "FAIL"),
    "plain_multiline": ("EXPECTED:\nuser can log in\npassword reset email sent\n\n" + PW_PASS, "FAIL"),
    "inline_plus_bullets": ("EXPECTED: user can log in\n- password reset email sent\n\n" + PW_PASS, "FAIL"),
    "all_tests_pass_and_more": ("EXPECTED: All tests pass and password reset email sent\n\n" + PW_PASS, "FAIL"),
    "all_tests_pass_bullet": ("EXPECTED:\n- All tests pass\n- checkout completes\n\n" + PW_PASS, "PASS"),
    "all_tests_pass_plus_negative": ("EXPECTED: All tests pass. No timeouts.\n\n" + PW_PASS, "PASS"),
    "filler_words_ignored": ("EXPECTED:\n- the user can log in\n\n" + PW_PASS, "PASS"),
    "star_bullets_met": ("EXPECTED:\n* user can log in\n* checkout completes\n\n" + PW_PASS, "PASS"),
    "scattered_words_are_not_evidence": (SCATTERED, "FAIL"),
}


@pytest.mark.parametrize("name", ROUND_TWO_CASES)
def test_round_two_heuristic(name):
    raw, want = ROUND_TWO_CASES[name]
    j = ev.heuristic_judge(*ev.extract_expected(raw))
    assert j.verdict == want, j.failed_checks


def test_leading_blank_line_before_header_is_still_a_header():
    expected, log = ev.extract_expected("\n\nEXPECTED:\n- password reset email sent\n\n" + PW_PASS)
    assert expected == "- password reset email sent"
    assert ev.heuristic_judge(expected, log).verdict == "FAIL"


def test_plain_multiline_block_keeps_every_line_out_of_the_log():
    expected, log = ev.extract_expected("EXPECTED:\nstep one\nstep two\n\n1 passed")
    assert expected == "step one\nstep two" and log == "1 passed"


def test_empty_expected_block_falls_back_to_default():
    expected, log = ev.extract_expected("EXPECTED:\n\n1 passed")
    assert expected == ev.DEFAULT_EXPECTED and log == "1 passed"


def test_flaky_retry_is_not_an_expected_step_failure():
    j = ev.heuristic_judge(*ev.extract_expected("EXPECTED:\n- loads dashboard\n\n" + PW_FLAKY))
    assert j.failed_checks == [] and "retry" in j.reason


def test_flaky_does_not_hide_other_problems():
    assert "assertion or test failure in log" in ev.heuristic_judge(
        ev.DEFAULT_EXPECTED, FLAKY_PLUS_REAL_FAILURE
    ).failed_checks
    checks = ev.heuristic_judge(ev.DEFAULT_EXPECTED, PW_FLAKY + "Error: global teardown timed out\n").failed_checks
    assert "timeout" in checks


def test_utf16_log_is_read(tmp_path):
    path = write(tmp_path, PW_PASS.encode("utf-16"), binary=True)
    assert "3 passed" in ev.read_text(path)
    assert ev.main([path]) == 0


def test_read_text_closes_the_file(tmp_path, recwarn):
    import gc, warnings
    path = write(tmp_path, PW_PASS)
    with warnings.catch_warnings():
        warnings.simplefilter("error", ResourceWarning)
        ev.read_text(path)
        gc.collect()


# ---- live, round two ----

@pytest.mark.parametrize(
    "kwargs",
    [
        {"raw": json.dumps({"choices": [{"message": {"content": None, "refusal": "no"}}]})},
        {"raw": json.dumps({"choices": [{"message": None}]})},
        {"raw": json.dumps({"choices": ["oops"]})},
        {"raw": "[]"},
        {"raw": "null"},
        {"raw": '"oops"'},
        {"raw": '{"error": "rate limited"}', "status": 429},
        {"raw": '"bad gateway"', "status": 502},
        {"raw": "", "status": 500},
    ],
    ids=["content_null", "message_null", "choice_not_object", "body_list", "body_null",
         "body_string", "http_error_string", "http_error_json_string", "http_empty_body"],
)
def test_live_odd_responses_raise_judge_error(mock_api, kwargs):
    mock_api.reply(**kwargs)
    with pytest.raises(ev.JudgeError):
        ev.live_judge("x", "y")


def test_live_http_error_reports_status_and_message(mock_api):
    mock_api.reply(raw='{"error": "rate limited"}', status=429)
    with pytest.raises(ev.JudgeError, match=r"429.*rate limited"):
        ev.live_judge("x", "y")


def test_live_refusal_text_is_surfaced(mock_api):
    mock_api.reply(raw=json.dumps({"choices": [{"message": {"content": None, "refusal": "cannot comply"}}]}))
    with pytest.raises(ev.JudgeError, match="cannot comply"):
        ev.live_judge("x", "y")


def test_live_prompt_has_single_braces_in_json_example(mock_api):
    mock_api.reply(reply())
    ev.live_judge("x", "y")
    assert "{{" not in mock_api.seen["prompt"] and "}}" not in mock_api.seen["prompt"]
    assert '{\n  "verdict"' in mock_api.seen["prompt"]


def test_live_placeholder_text_in_expected_is_left_alone(mock_api):
    mock_api.reply(reply())
    ev.live_judge("see {log} output", "UNIQUE-LOG-LINE")
    assert mock_api.seen["prompt"].count("UNIQUE-LOG-LINE") == 1
    assert "see {log} output" in mock_api.seen["prompt"]


@pytest.mark.parametrize("items", [[""], [None], ["  "], [None, ""]])
def test_live_empty_failed_check_items_do_not_flip_a_pass(mock_api, items):
    mock_api.reply(reply(failed_checks=items))
    j = ev.live_judge("x", "y")
    assert j.verdict == "PASS" and j.failed_checks == []


def test_live_decimal_string_score_is_rounded(mock_api):
    mock_api.reply(reply(score="87.6"))
    assert ev.live_judge("x", "y").score == 88


def test_live_strict_flag_reaches_the_prompt(tmp_path, mock_api):
    mock_api.reply(reply())
    path = write(tmp_path, PW_PASS)
    assert ev.main([path, "--live"]) == 0
    assert ev.LENIENT_RULE in mock_api.seen["prompt"] and ev.STRICT_RULE not in mock_api.seen["prompt"]
    assert ev.main([path, "--live", "--strict"]) == 0
    assert ev.STRICT_RULE in mock_api.seen["prompt"] and ev.LENIENT_RULE not in mock_api.seen["prompt"]


@pytest.mark.parametrize(
    "raw",
    ['{"choices": [{"message": {"content": null}}]}', "[]", '"oops"'],
    ids=["content_null", "body_list", "body_string"],
)
def test_cli_live_odd_responses_exit_2_without_traceback(tmp_path, mock_api, capsys, raw):
    mock_api.reply(raw=raw)
    assert ev.main([write(tmp_path, PW_PASS), "--live"]) == 2
    assert "JUDGE ERROR" in capsys.readouterr().err


def test_ansi_colour_codes_are_ignored():
    green, red, dim, off = "\x1b[32m", "\x1b[31m", "\x1b[2m", "\x1b[0m"
    passing = f"  {green}\u2713{off}  1 a.spec.ts \u203a loads {dim}(1s){off}\n\n{green}  1 passed{off}{dim} (1s){off}\n"
    failing = f"  {red}\u2718{off}  1 a.spec.ts \u203a loads {dim}(1s){off}\n\n{red}  1 failed{off}\n"
    assert ev.heuristic_judge(ev.DEFAULT_EXPECTED, passing).verdict == "PASS"
    assert ev.heuristic_judge(ev.DEFAULT_EXPECTED, failing).verdict == "FAIL"


def test_stray_bytes_do_not_destroy_markers(tmp_path):
    data = b"caf\xe9 log\n" + PW_PASS.encode("utf-8")
    assert "\u2713" in ev.read_text(write(tmp_path, data, binary=True))
